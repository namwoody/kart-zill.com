/**
 * Woothemes Tumblog Functionality
 * JQuery
 *
 * @version 2.0.0
 *
 * @package WooFramework
 * @subpackage Tumblog
 */

// Deprecated