<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
// Express is no longer available and, therefore, no longer supported within the WooFramework.
// To continue to use Express, please use the WooTumblog plugin. http://wordpress.org/plugins/woo-tumblog/.
?>